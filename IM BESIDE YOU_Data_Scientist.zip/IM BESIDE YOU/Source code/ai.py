import json
import re
from dotenv import load_dotenv
from langflow.load import run_flow_from_json
from typing import Optional

load_dotenv()

def dict_to_string(obj, level=0):
    strings = []
    indent = "  " * level
    if isinstance(obj, dict):
        for key, value in obj.items():
            if isinstance(value, (dict, list)):
                nested_string = dict_to_string(value, level + 1)
                strings.append(f"{indent}{key}: {nested_string}")
            else:
                strings.append(f"{indent}{key}: {value}")
    elif isinstance(obj, list):
        for idx, item in enumerate(obj):
            nested_string = dict_to_string(item, level + 1)
            strings.append(f"{indent}Item {idx + 1}: {nested_string}")
    else:
        strings.append(f"{indent}{obj}")
    return ", ".join(strings)

def ask_ai(profile, question, session_id="default_session"):
    """
    Runs the AskAIV2 flow LOCALLY.
    """
    try:
        TWEAKS = {
            "TextInput-QYxrd": {  # User question input
                "input_value": question
            },
            "TextInput-alnRg": {  # Profile input
                "input_value": dict_to_string(profile)
            },
        }
        
        # Run the flow locally - REMOVED user_id parameter, using session_id instead
        result = run_flow_from_json(
            flow="AskAIV2.json",
            input_value=question,
            tweaks=TWEAKS,
            session_id=session_id,
            fallback_to_env_vars=True
        )
        
        # Debug: Print the result structure
        print("Ask AI Result structure:", type(result))
        if result:
            print("Result length:", len(result))
            print("First result:", result[0] if len(result) > 0 else "No results")
        
        # Try different ways to extract the response
        if result and len(result) > 0:
            first_result = result[0]
            
            # Try accessing outputs
            if hasattr(first_result, 'outputs'):
                outputs = first_result.outputs
                if outputs and len(outputs) > 0:
                    first_output = outputs[0]
                    
                    # Try results with nested structure (like macro flow)
                    if hasattr(first_output, 'results'):
                        results = first_output.results
                        
                        # Try the same pattern that works for macros
                        try:
                            if isinstance(results, dict) and 'text' in results:
                                text_data = results['text']
                                if hasattr(text_data, 'data') and isinstance(text_data.data, dict):
                                    if 'text' in text_data.data:
                                        response_text = text_data.data['text']
                                        # Clean up markdown code blocks if present
                                        if isinstance(response_text, str):
                                            response_text = response_text.strip()
                                            if response_text.startswith("```"):
                                                lines = response_text.split('\n')
                                                if len(lines) > 2:
                                                    response_text = '\n'.join(lines[1:-1])
                                        return response_text
                        except Exception as e:
                            print(f"Error extracting from nested structure: {e}")
                        
                        # Try direct text access from results
                        if isinstance(results, str):
                            return results
                    
                    # Try message.text
                    if hasattr(first_output, 'message'):
                        if hasattr(first_output.message, 'text'):
                            return first_output.message.text
                        elif hasattr(first_output.message, 'content'):
                            return first_output.message.content
                    
                    # Try direct text access
                    if hasattr(first_output, 'text'):
                        return first_output.text
            
            # Try direct text attribute
            if hasattr(first_result, 'text'):
                return first_result.text
            
            # Try message attribute
            if hasattr(first_result, 'message'):
                if hasattr(first_result.message, 'text'):
                    return first_result.message.text
        
        # If nothing works, return string representation
        return f"Response received but couldn't extract text. Result: {str(result)}"
        
    except Exception as e:
        error_msg = f"Error in ask_ai: {str(e)}\nType: {type(e).__name__}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        return error_msg

def _make_serializable(x):
    if x is None:
        return None
    if isinstance(x, (str, int, float, bool)):
        return x
    if isinstance(x, list):
        return [_make_serializable(i) for i in x]
    if isinstance(x, dict):
        return {str(k): _make_serializable(v) for k, v in x.items()}
    
    try:
        d = getattr(x, "dict", None)
        if callable(d):
            return _make_serializable(d())
    except Exception:
        pass
    
    try:
        d = getattr(x, "__dict__", None)
        if isinstance(d, dict):
            return _make_serializable(d)
    except Exception:
        pass
    
    try:
        return json.loads(str(x))
    except Exception:
        pass
    
    return str(x)

def get_macros(profile, goals, session_id="default_session"):
    """
    Gets macro recommendations from the AI flow.
    """
    try:
        TWEAKS = {
            "TextInput-BtiQi": {  # Goals input
                "input_value": ", ".join(goals) if isinstance(goals, list) else str(goals)
            },
            "TextInput-H23aR": {  # Profile input
                "input_value": dict_to_string(profile)
            },
        }
        
        # Run the flow locally - REMOVED user_id parameter, using session_id instead
        result = run_flow_from_json(
            flow="Macro-Flow.json",
            input_value="",
            tweaks=TWEAKS,
            session_id=session_id,
            fallback_to_env_vars=True
        )
        
        # Debug: Print result structure
        print("Macro Flow Result structure:", type(result))
        if result:
            print("Result length:", len(result))
        
        # Multiple ways to access the result
        access_attempts = [
            lambda r: r[0].outputs[0].results["text"]["data"]["text"],
            lambda r: r[0].outputs[0].results["text"]["data"]["content"],
            lambda r: r[0].outputs[0].results.get("output_text"),
            lambda r: r[0].outputs[0].text,
            lambda r: r[0].outputs[0].message.text,
            lambda r: r[0].outputs[0].message.content,
            lambda r: r[0].outputs[0].data.text,
            lambda r: r[0].outputs[0].results,
            lambda r: r[0].text,
            lambda r: r[0].message.text if hasattr(r[0], 'message') else None,
        ]
        
        candidate = None
        for attempt in access_attempts:
            try:
                candidate = attempt(result)
                if candidate is not None:
                    print(f"Successfully extracted using method: {attempt.__code__.co_code}")
                    print(f"Extracted value: {candidate}")
                    break
            except Exception as e:
                continue
        
        if candidate is None:
            print("Could not extract data from result. Full result:")
            print(result)
            # Try to serialize the entire result
            candidate = _make_serializable(result)
        
        parsed = _make_serializable(candidate)
        
        # Try to parse as JSON if it's a string
        if isinstance(parsed, str):
            # Clean up the string - remove markdown code blocks if present
            cleaned = parsed.strip()
            if cleaned.startswith("```json"):
                cleaned = cleaned[7:]
            if cleaned.startswith("```"):
                cleaned = cleaned[3:]
            if cleaned.endswith("```"):
                cleaned = cleaned[:-3]
            cleaned = cleaned.strip()
            
            try:
                parsed = json.loads(cleaned)
                print(f"Successfully parsed JSON: {parsed}")
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {e}")
                print(f"String that failed to parse: {cleaned}")
        
        # If we have a dictionary with the right keys, return it
        if isinstance(parsed, dict):
            out = {}
            for k in ("calories", "protein", "fat", "carbs"):
                if k in parsed:
                    out[k] = parsed[k]
            if out:
                print(f"Returning macro values: {out}")
                return out
        
        # Try regex extraction as fallback
        s = json.dumps(parsed) if not isinstance(parsed, str) else parsed
        print(f"Attempting regex extraction on: {s}")
        
        patterns = {
            "calories": r"calor(?:y|ies)[^\d]*([0-9]{2,5})",
            "protein": r"protein[^\d]*([0-9]{1,4})",
            "fat": r"fat[^\d]*([0-9]{1,4})",
            "carbs": r"carb[s]?[^\d]*([0-9]{1,4})"
        }
        
        found = {}
        for k, p in patterns.items():
            m = re.search(p, s, flags=re.IGNORECASE)
            if m:
                try:
                    found[k] = int(m.group(1))
                except Exception:
                    try:
                        found[k] = float(m.group(1))
                    except Exception:
                        pass
        
        if found:
            print(f"Regex extraction found: {found}")
            return found
        
        print("Could not extract macro values. Returning empty dict.")
        return {}
        
    except Exception as e:
        error_msg = f"Error in get_macros: {str(e)}\nType: {type(e).__name__}"
        print(error_msg)
        import traceback
        traceback.print_exc()
        return {}