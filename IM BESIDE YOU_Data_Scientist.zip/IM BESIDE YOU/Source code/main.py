import streamlit as st
from ai import ask_ai, get_macros
from profiles import create_profile, get_notes, get_profile
from form_submit import update_personal_info, add_note, delete_note

st.title("Personal Fitness Tool")

@st.fragment()
def personal_data_form():
    with st.form("personal_data"):
        st.header("Personal Data")
        profile = st.session_state.profile
        name = st.text_input("Name", value=profile["general"]["name"])
        age = st.number_input(
            "Age", min_value=1, max_value=120, step=1, value=profile["general"]["age"]
        )
        weight = st.number_input(
            "Weight (kg)",
            min_value=0.0,
            max_value=300.0,
            step=0.1,
            value=float(profile["general"]["weight"]),
        )
        height = st.number_input(
            "Height (cm)",
            min_value=0.0,
            max_value=250.0,
            step=0.1,
            value=float(profile["general"]["height"]),
        )
        genders = ["Male", "Female", "Other"]
        gender = st.radio(
            "Gender", genders, index=genders.index(profile["general"].get("gender", "Male"))
        )
        activities = (
            "Sedentary",
            "Lightly Active",
            "Moderately Active",
            "Very Active",
            "Super Active",
        )
        activity_level = st.selectbox(
            "Activity Level",
            activities,
            index=activities.index(
                profile["general"].get("activity_level", "Sedentary")
            ),
        )
        personal_data_submit = st.form_submit_button("Save")

        if personal_data_submit:
            if all([name, age, weight, height, gender, activity_level]):
                with st.spinner():
                    st.session_state.profile = update_personal_info(
                        profile,
                        "general",
                        name=name,
                        weight=weight,
                        height=height,
                        gender=gender,
                        age=age,
                        activity_level=activity_level,
                    )
                st.success("Information saved.")
            else:
                st.warning("Please fill in all of the data!")

@st.fragment()
def goals_form():
    profile = st.session_state.profile
    with st.form("goals_form"):
        st.header("Goals")
        goals = st.multiselect(
            "Select your Goals",
            ["Muscle Gain", "Fat Loss", "Stay Active"],
            default=profile.get("goals", ["Muscle Gain"]),
        )
        goals_submit = st.form_submit_button("Save")

        if goals_submit:
            if goals:
                with st.spinner():
                    st.session_state.profile = update_personal_info(
                        profile, "goals", goals=goals
                    )
                st.success("Goals updated")
            else:
                st.warning("Please select at least one goal.")

@st.fragment()
def macros():
    st.header("Nutrition")
    profile = st.session_state.profile

    # Display current macros
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Calories", profile.get("nutrition", {}).get("calories", 2000))
    with col2:
        st.metric("Protein (g)", profile.get("nutrition", {}).get("protein", 140))
    with col3:
        st.metric("Fat (g)", profile.get("nutrition", {}).get("fat", 20))
    with col4:
        st.metric("Carbs (g)", profile.get("nutrition", {}).get("carbs", 100))

    # Generate with AI button
    if st.button("Generate with AI"):
        with st.spinner("Generating macros..."):
            try:
                result = get_macros(
                    profile.get("general"),
                    profile.get("goals"),
                    session_id=str(st.session_state.profile_id)  # FIXED: Changed from user_id to session_id
                )

                safe_fields = {}
                for key in ("calories", "protein", "fat", "carbs"):
                    if key in result:
                        val = result[key]
                        if isinstance(val, (int, float)):
                            safe_fields[key] = val
                        else:
                            try:
                                safe_fields[key] = int(val)
                            except Exception:
                                try:
                                    safe_fields[key] = float(val)
                                except Exception:
                                    pass

                if safe_fields:
                    st.session_state.profile = update_personal_info(
                        profile, "nutrition", **safe_fields
                    )
                    st.success("AI has generated the results.")
                    st.rerun()
                else:
                    st.error("Could not extract valid macro values from AI response.")
            except Exception as e:
                st.error(f"Error generating macros: {str(e)}")

@st.fragment()
def notes():
    st.subheader("Notes: ")
    for i, note in enumerate(st.session_state.notes):
        cols = st.columns([5, 1])
        with cols[0]:
            st.text(note.get("text"))
        with cols[1]:
            if st.button("Delete", key=i):
                delete_note(note.get("_id"))
                st.session_state.notes.pop(i)
                st.rerun()

    new_note = st.text_input("Add a new note: ")
    if st.button("Add Note"):
        if new_note:
            note = add_note(new_note, st.session_state.profile_id)
            st.session_state.notes.append(note)
            st.rerun()

@st.fragment()
def ask_ai_func():
    st.subheader('Ask AI')
    user_question = st.text_input("Ask AI a question: ")
    if st.button("Ask AI"):
        if user_question:
            with st.spinner("Getting AI response..."):
                try:
                    result = ask_ai(
                        st.session_state.profile,
                        user_question,
                        session_id=str(st.session_state.profile_id)  # FIXED: Changed from user_id to session_id
                    )
                    st.write(result)
                except Exception as e:
                    st.error(f"Error asking AI: {str(e)}")
        else:
            st.warning("Please enter a question.")

def forms():
    if "profile" not in st.session_state:
        profile_id = 1
        profile = get_profile(profile_id)
        if not profile:
            profile_id, profile = create_profile(profile_id)
        st.session_state.profile = profile
        st.session_state.profile_id = profile_id

    if "notes" not in st.session_state:
        st.session_state.notes = get_notes(st.session_state.profile_id)

    personal_data_form()
    goals_form()
    macros()
    notes()
    ask_ai_func()

if __name__ == "__main__":
    forms()